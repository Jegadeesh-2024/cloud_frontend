import { useNavigate } from "react-router-dom";

const Dashboard = () => {

  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div className="p-10">

      <h1 className="text-3xl font-bold mb-6">
        Dashboard
      </h1>

      <button
        onClick={logout}
        className="bg-red-500 text-white px-6 py-2 rounded"
      >
        Logout
      </button>

    </div>
  );
};

export default Dashboard;