import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import { toast } from "react-toastify";

const Register = () => {

  const navigate = useNavigate();

  const [form,setForm] = useState({
    name:"",
    email:"",
    password:""
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e)=>{
    setForm({...form,[e.target.name]:e.target.value});
  };

  const handleSubmit = async (e)=>{
    e.preventDefault();
     let newErrors = {};

    if (!form.email) {
      newErrors.email = "Email is required";
    }
    if (!form.name) {
      newErrors.name = "Name is required";
    }

    if (!form.password) {
      newErrors.password = "Password is required";
    }

    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) {
    return;
  }

    try {

      const res = await axios.post(
        "http://localhost:5000/api/register",
        form
      );

      console.log(res.data);

      if(res.data.success){
      toast.success("Registration Successful");
        navigate("/");
      }else{
         toast.error(res.data.message);

      }

    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">

      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-lg w-96">

        <h2 className="text-2xl font-bold text-center mb-6">Register</h2>

        <input
          type="text"
          name="name"
          value={form.name}
          placeholder="Name"
          onChange={handleChange}
          className="w-full border p-3 mb-4 rounded-lg"
        />
         {errors.name && (
          <p className="text-red-500 text-sm mt-1 mb-3">
            {errors.name}
          </p>
        )}

        <input
          type="email"
          name="email"
          value={form.email}
          placeholder="Email"
          onChange={handleChange}
          className="w-full border p-3 mb-4 rounded-lg"
        />
         {errors.email && (
          <p className="text-red-500 text-sm mt-1 mb-3">
            {errors.email}
          </p>
        )}

        <input
          type="password"
          value={form.password}
          name="password"
          placeholder="Password"
          onChange={handleChange}
          className="w-full border p-3 mb-4 rounded-lg"
        />
         {errors.password && (
          <p className="text-red-500 text-sm mt-1 mb-3">
            {errors.password}
          </p>
        )}

        <button className="w-full bg-blue-500 text-white py-2 rounded-lg">
          Register
        </button>

        <p className="text-center mt-4">
          Already have account? <Link to="/" className="text-blue-500">Login</Link>
        </p>

      </form>

    </div>
  );
};

export default Register;