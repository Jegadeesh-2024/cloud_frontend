import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import { toast } from "react-toastify";

const Login = () => {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState({});
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let newErrors = {};

    if (!form.email) {
      newErrors.email = "Email is required";
    }

    if (!form.password) {
      newErrors.password = "Password is required";
    }

    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) {
      return;
    }

    try {
      const res = await axios.post("http://localhost:5000/api/login", form);

      console.log(res.data);

      if (res.data.success) {
        localStorage.setItem("token", res.data.token);

        toast.success("Login Successful");
        navigate("/dashboard");
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      console.log(error);
      toast.error("Server Error");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <form
        onSubmit={handleSubmit}
        className="bg-white p-8 rounded-xl shadow-lg w-96"
      >
        <h2 className="text-2xl font-bold text-center mb-6">Login</h2>

        <input
          type="text"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          className="w-full border p-3 mb-4 rounded-lg"
        />
        {errors.email && (
          <p className="text-red-500 text-sm mt-1 mb-3">{errors.email}</p>
        )}

        <input
          type="password"
          name="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          className="w-full border p-3 mb-4 rounded-lg"
        />
        {errors.password && (
          <p className="text-red-500 text-sm mt-1 mb-3">{errors.password}</p>
        )}

        <button className="w-full bg-green-500 text-white py-2 rounded-lg">
          Login
        </button>
       

        <p className="text-center mt-4">
          Don't have account?{" "}
          <Link to="/register" className="text-blue-500">
            Register
          </Link>
        </p>
      </form>
       {/* <button
          onClick={() =>
            window.open("http://localhost:5000/auth/google", "_self")
          }
          className="cursor-pointer bg-red-500 text-white px-4 py-2 rounded"
        >
          Login with Google
        </button> */}
    </div>
  );
};

export default Login;
